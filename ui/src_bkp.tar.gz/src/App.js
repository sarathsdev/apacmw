import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from "react-router-dom";
import './App.css';
import citiLogo from './citibank-logo.png';
import Home from "./pages/Home";
import KnowledgeBase from './pages/KnowledgeBase'; 
import Administration from './pages/Administration';
import Automation from './pages/Automation';
import BAU from './pages/BAU';
import Contact from './pages/Contact';
import Access from './pages/Access';
import AddIssue from './pages/AddIssue'; 
const Navbar = () => {
  const navigate = useNavigate();
  
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <ul className="nav-links">
          <li><Link to="/">Home</Link></li>
          <li onClick={() => navigate("/administration")} style={{ cursor: "pointer" }}>Administration</li>
          <li onClick={() => navigate("/knowledge-base")} style={{ cursor: "pointer" }}>Knowledge Base</li>
          <li onClick={() => navigate("/automation")} style={{ cursor: "pointer" }}>Automation</li>
          <li onClick={() => navigate("/access")} style={{ cursor: "pointer" }}>iAccess</li>
          <li onClick={() => navigate("/bau")} style={{ cursor: "pointer" }}>BAU</li>
          <li onClick={() => navigate("/contact")} style={{ cursor: "pointer" }}>Contact</li>
        </ul>
        <div className="user-container">
          <button className="auth-button">Sign In</button>
        </div>
      </div>
    </nav>
  );
};

const App = () => {
  return (
    <Router>
      <div className="app-container">
        <header className="header">
          <div className="logo-container">
            <img src={citiLogo} alt="Citi Bank Logo" className="logo" />
            <h1>APAC Middleware</h1>
          </div>
          <Navbar />
        </header>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/knowledge-base" element={<KnowledgeBase />} />
            <Route path="/administration" element={<Administration />} />
            <Route path="/automation" element={<Automation />} />
            <Route path="/access" element={<Access />} />
            <Route path="/bau" element={<BAU />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/add" element={<AddIssue />} />
          </Routes>
        </main>

        <footer className="footer">
          <p>Copyright © 2025 | Contact us | Share Feedback</p>
        </footer>
      </div>
    </Router>
  );
};

export default App;
