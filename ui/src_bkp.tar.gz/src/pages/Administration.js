import React, { useState, useEffect } from "react";
import axios from "axios";
import './Administration.css';

const Administration = () => {
  const [tasks, setTasks] = useState([]);
  const [filters, setFilters] = useState({
    taskType: "",
    priority: "",
  });

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/tasks");
        setTasks(response.data);
      } catch (err) {
        console.error("Error fetching tasks:", err);
      }
    };

    fetchTasks();
  }, []);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  const filteredTasks = tasks.filter((task) => {
    const { taskType, priority } = filters;
    return (
      (taskType === "" || task.taskType === taskType) &&
      (priority === "" || task.priority === priority)
    );
  });

  return (
    <div className="administrative-page-container">
      <h1 className="administrative-page-heading">Administrative Tasks</h1>

      {/* Filters */}
      <form className="administrative-filter-form">
        <div className="administrative-filter-grid">
          {/* Task Type Filter */}
          <div>
            <label className="administrative-filter-label">Task Type:</label>
            <select
              name="taskType"
              value={filters.taskType}
              onChange={handleFilterChange}
              className="administrative-filter-select"
            >
              <option value="">All</option>
              <option value="Meeting">Meeting</option>
              <option value="Document Review">Document Review</option>
              <option value="Staff Management">Staff Management</option>
            </select>
          </div>

          {/* Priority Filter */}
          <div>
            <label className="administrative-filter-label">Priority:</label>
            <select
              name="priority"
              value={filters.priority}
              onChange={handleFilterChange}
              className="administrative-filter-select"
            >
              <option value="">All</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>
      </form>

      {/* Task Display */}
      {filteredTasks.length === 0 ? (
        <p className="no-tasks-text">No tasks found.</p>
      ) : (
        filteredTasks.map((task, index) => (
          <div key={index} className="administrative-task-card">
            <h3 className="task-title">{task.title}</h3>
            <p><strong>Task Type:</strong> {task.taskType}</p>
            <p><strong>Priority:</strong> {task.priority}</p>
            <p><strong>Description:</strong> {task.description}</p>
          </div>
        ))
      )}

      {/* Add New Task Button */}
      <div className="add-task-container">
        <button className="add-task-button">Add New Task</button>
      </div>
    </div>
  );
};

export default Administration;
