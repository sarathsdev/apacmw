import React from "react";
import { Link } from "react-router-dom";
import IssueList from "../components/IssueList";
import "./KnowledgeBase.css";

const KnowledgeBase = () => {
  return (
    <div className="knowledge-base-container">
      <div className="knowledge-base-header">
        <Link to="/add">
          <button className="add-issue-button">
            Add New Issue
          </button>
        </Link>
      </div>
      <IssueList />
    </div>
  );
};

export default KnowledgeBase;
