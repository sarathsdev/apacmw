import React from 'react'

export default function Home() {
    return (
        <div>
            <main className="main-content">

                <div className="cards-container">
                    <div className="card">
                        <h3>WEBaaS</h3>
                        <ul>
                            <li>CAS Software Provisioning</li>
                            <li>Initiate Build Activity</li>
                            <li>My orders</li>
                        </ul>
                        <button>Go to WEBaaS</button>
                    </div>

                    <div className="card">
                        <h3>Maker/Checker</h3>
                        <ul>
                            <li>Nginx</li>
                            <li>Apache HTTP Server</li>
                            <li>Tomcat</li>
                            <li>IBM HTTP Server</li>
                            <li>WebSphere ND</li>
                            <li>Oracle HTTP Server</li>
                            <li>WebLogic</li>
                        </ul>
                        <button>Go to Maker/Checker</button>
                    </div>

                    <div className="card">
                        <h3>Dashboard</h3>
                        <ul>
                            <li>WEBaaS Live Dashboard</li>
                            <li>Maker/Checker Live Dashboard</li>
                        </ul>
                        <button>Go to Live View Dashboard</button>
                    </div>
                </div>
            </main>
        </div>
    )
}
